using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace PozdravlyatorGUI
{
    public partial class Form1 : MaterialForm
    {
        private readonly MaterialSkinManager materialSkinManager;
        private readonly BirthdayService service =
            new BirthdayService("birthdays.json");

        private int? editingId = null;

        public Form1()
        {
            InitializeComponent();

            materialSkinManager =
                MaterialSkinManager.Instance;

            materialSkinManager.AddFormToManage(this);

            materialSkinManager.Theme =
                MaterialSkinManager.Themes.DARK;

            materialSkinManager.ColorScheme =
                new ColorScheme(
                    Primary.BlueGrey800,
                    Primary.BlueGrey900,
                    Primary.BlueGrey500,
                    Accent.LightBlue200,
                    TextShade.WHITE);

            RefreshList();

            ShowTodayBirthdays();
        }

        private void ShowTodayBirthdays()
        {
            var today = service.GetToday().ToList();

            if (!today.Any())
                return;

            var text = string.Join(
                Environment.NewLine,
                today.Select(x => $"🎉 {x.Name}"));

            MessageBox.Show(
                text,
                "Сегодня день рождения",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void RefreshList(
            IEnumerable<BirthdayEntry>? data = null)
        {
            listBox1.Items.Clear();

            foreach (var item in data ?? service.GetAll())
            {
                listBox1.Items.Add(
                    new MaterialListBoxItem(
                        item.ToString()));
            }
        }

        private void ClearInputs()
        {
            txtName.Text = "";
            txtComment.Text = "";
            dateTimePicker1.Value = DateTime.Today;
            editingId = null;
        }

        private void btnAdd_Click(
            object sender,
            EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show(
                    "Введите имя.",
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            service.Add(
                txtName.Text,
                dateTimePicker1.Value,
                txtComment.Text);

            RefreshList();
            ClearInputs();
        }

        private void btnRemove_Click(
            object sender,
            EventArgs e)
        {
            if (listBox1.SelectedIndex < 0)
                return;

            var result = MessageBox.Show(
                "Удалить запись?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result != DialogResult.Yes)
                return;

            var entry = service.GetAll()
                .ElementAt(listBox1.SelectedIndex);

            service.Remove(entry.Id);

            RefreshList();
        }

        private void btnEdit_Click(
            object sender,
            EventArgs e)
        {
            if (editingId == null)
            {
                if (listBox1.SelectedIndex < 0)
                    return;

                var entry = service.GetAll()
                    .ElementAt(listBox1.SelectedIndex);

                editingId = entry.Id;

                txtName.Text = entry.Name;
                txtComment.Text = entry.Comment;
                dateTimePicker1.Value = entry.Date;

                btnEdit.Text = "Сохранить";
            }
            else
            {
                service.Edit(
                    editingId.Value,
                    txtName.Text,
                    dateTimePicker1.Value,
                    txtComment.Text);btnEdit.Text =
                    "Редактировать";

                RefreshList();
                ClearInputs();
            }
        }

        private void btnShowAll_Click(
            object sender,
            EventArgs e)
        {
            RefreshList();
        }

        private void btnShowToday_Click(
            object sender,
            EventArgs e)
        {
            RefreshList(service.GetToday());
        }

        private void btnShowUpcoming_Click(
            object sender,
            EventArgs e)
        {
            RefreshList(service.GetUpcoming(30));
        }
    }
}