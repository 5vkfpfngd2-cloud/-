﻿namespace PozdravlyatorGUI
{
    partial class Form1
    {
        private MaterialSkin.Controls.MaterialListBox listBox1;
        private MaterialSkin.Controls.MaterialTextBox txtName;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MaterialSkin.Controls.MaterialTextBox txtComment;

        private MaterialSkin.Controls.MaterialButton btnAdd;
        private MaterialSkin.Controls.MaterialButton btnEdit;
        private MaterialSkin.Controls.MaterialButton btnRemove;

        private MaterialSkin.Controls.MaterialButton btnShowAll;
        private MaterialSkin.Controls.MaterialButton btnShowToday;
        private MaterialSkin.Controls.MaterialButton btnShowUpcoming;

        private System.Windows.Forms.TableLayoutPanel actionsPanel;
        private System.Windows.Forms.TableLayoutPanel filtersPanel;

        private void InitializeComponent()
        {
            this.listBox1 = new MaterialSkin.Controls.MaterialListBox();
            this.txtName = new MaterialSkin.Controls.MaterialTextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtComment = new MaterialSkin.Controls.MaterialTextBox();

            this.btnAdd = new MaterialSkin.Controls.MaterialButton();
            this.btnEdit = new MaterialSkin.Controls.MaterialButton();
            this.btnRemove = new MaterialSkin.Controls.MaterialButton();

            this.btnShowAll = new MaterialSkin.Controls.MaterialButton();
            this.btnShowToday = new MaterialSkin.Controls.MaterialButton();
            this.btnShowUpcoming = new MaterialSkin.Controls.MaterialButton();

            this.actionsPanel = new System.Windows.Forms.TableLayoutPanel();
            this.filtersPanel = new System.Windows.Forms.TableLayoutPanel();

            this.SuspendLayout();

            //
            // listBox1
            //
            this.listBox1.Location =
                new System.Drawing.Point(20, 80);

            this.listBox1.Size =
                new System.Drawing.Size(760, 220);

            //
            // txtName
            //
            this.txtName.Location =
                new System.Drawing.Point(20, 320);

            this.txtName.Size =
                new System.Drawing.Size(220, 50);

            this.txtName.Hint = "Имя";

            //
            // dateTimePicker1
            //
            this.dateTimePicker1.Location =
                new System.Drawing.Point(260, 335);

            this.dateTimePicker1.Size =
                new System.Drawing.Size(180, 23);

            //
            // txtComment
            //
            this.txtComment.Location =
                new System.Drawing.Point(460, 320);

            this.txtComment.Size =
                new System.Drawing.Size(320, 50);

            this.txtComment.Hint = "Комментарий";

            //
            // Кнопки действий
            //
            this.btnAdd.Text = "Добавить";
            this.btnEdit.Text = "Изменить";
            this.btnRemove.Text = "Удалить";

            this.btnAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRemove.Dock = System.Windows.Forms.DockStyle.Fill;

            this.btnAdd.Click +=
                new System.EventHandler(this.btnAdd_Click);

            this.btnEdit.Click +=
                new System.EventHandler(this.btnEdit_Click);

            this.btnRemove.Click +=
                new System.EventHandler(this.btnRemove_Click);

            //
            // actionsPanel
            //
            this.actionsPanel.ColumnCount = 3;
            this.actionsPanel.RowCount = 1;

            this.actionsPanel.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(
                    System.Windows.Forms.SizeType.Percent, 33.33F));

            this.actionsPanel.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(
                    System.Windows.Forms.SizeType.Percent, 33.33F));

            this.actionsPanel.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(
                    System.Windows.Forms.SizeType.Percent, 33.33F));

            this.actionsPanel.Location =
                new System.Drawing.Point(100, 390);

            this.actionsPanel.Size =
                new System.Drawing.Size(600, 40);

            this.actionsPanel.Controls.Add(this.btnAdd, 0, 0);
            this.actionsPanel.Controls.Add(this.btnEdit, 1, 0);
            this.actionsPanel.Controls.Add(this.btnRemove, 2, 0);

            //
            // Кнопки фильтров
            //
            this.btnShowAll.Text = "Все ДР";
            this.btnShowToday.Text = "Сегодня";
            this.btnShowUpcoming.Text = "30 дней";

            this.btnShowAll.Dock =
                System.Windows.Forms.DockStyle.Fill;

            this.btnShowToday.Dock =
                System.Windows.Forms.DockStyle.Fill;

            this.btnShowUpcoming.Dock =
                System.Windows.Forms.DockStyle.Fill;

            this.btnShowAll.Click +=
                new System.EventHandler(this.btnShowAll_Click);

            this.btnShowToday.Click +=
                new System.EventHandler(this.btnShowToday_Click);

            this.btnShowUpcoming.Click +=
                new System.EventHandler(this.btnShowUpcoming_Click);

            //
            // filtersPanel
            //
            this.filtersPanel.ColumnCount = 3;
            this.filtersPanel.RowCount = 1;

            this.filtersPanel.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(
                    System.Windows.Forms.SizeType.Percent, 33.33F));

            this.filtersPanel.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(
                    System.Windows.Forms.SizeType.Percent, 33.33F));

            this.filtersPanel.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(
                    System.Windows.Forms.SizeType.Percent, 33.33F));

            this.filtersPanel.Location =
                new System.Drawing.Point(100, 445);

            this.filtersPanel.Size =
                new System.Drawing.Size(600, 40);

            this.filtersPanel.Controls.Add(this.btnShowAll, 0, 0);
            this.filtersPanel.Controls.Add(this.btnShowToday, 1, 0);
            this.filtersPanel.Controls.Add(this.btnShowUpcoming, 2, 0);

            //
            // Form1
            //
            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize =
                new System.Drawing.Size(800, 540);

            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;

            this.Text = "Поздравлятор";

            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtComment);

            this.Controls.Add(this.actionsPanel);
            this.Controls.Add(this.filtersPanel);

            this.Name = "Form1";

            this.ResumeLayout(false);
        }
    }
}