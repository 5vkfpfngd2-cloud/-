using System;

namespace PozdravlyatorGUI
{
    public class BirthdayEntry
    {
        public int Id { get; set; }

        public string Name { get; set; } = "";

        public DateTime Date { get; set; }

        public string? Comment { get; set; }

        public int Age
        {
            get
            {
                int age = DateTime.Today.Year - Date.Year;

                if (DateTime.Today < Date.AddYears(age))
                    age--;

                return age;
            }
        }

        public DateTime NextBirthday
        {
            get
            {
                var next = new DateTime(
                    DateTime.Today.Year,
                    Date.Month,
                    Date.Day);

                if (next < DateTime.Today)
                    next = next.AddYears(1);

                return next;
            }
        }

        public int DaysLeft =>
            (NextBirthday - DateTime.Today).Days;

        public override string ToString()
        {
            return $"{Name} | {Date:dd.MM.yyyy} | {Age} лет | через {DaysLeft} дн. | {Comment}";
        }
    }
}