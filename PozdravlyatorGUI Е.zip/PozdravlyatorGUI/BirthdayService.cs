using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace PozdravlyatorGUI
{
    public class BirthdayService
    {
        private readonly string _filePath;
        private readonly List<BirthdayEntry> _entries = new();
        private int _nextId = 1;

        public BirthdayService(string filePath)
        {
            _filePath = filePath;
            Load();
        }

        public IEnumerable<BirthdayEntry> GetAll()
        {
            return _entries
                .OrderBy(x => x.NextBirthday);
        }

        public IEnumerable<BirthdayEntry> GetToday()
        {
            var today = DateTime.Today;

            return _entries.Where(x =>
                x.Date.Month == today.Month &&
                x.Date.Day == today.Day);
        }

        public IEnumerable<BirthdayEntry> GetUpcoming(int days)
        {
            return _entries
                .Where(x => x.DaysLeft <= days)
                .OrderBy(x => x.DaysLeft);
        }

        public BirthdayEntry Add(
            string name,
            DateTime date,
            string? comment)
        {
            var entry = new BirthdayEntry
            {
                Id = _nextId++,
                Name = name.Trim(),
                Date = date,
                Comment = comment
            };

            _entries.Add(entry);

            Save();

            return entry;
        }

        public bool Remove(int id)
        {
            var item = _entries.FirstOrDefault(x => x.Id == id);

            if (item == null)
                return false;

            _entries.Remove(item);

            Save();

            return true;
        }

        public bool Edit(
            int id,
            string? name,
            DateTime? date,
            string? comment)
        {
            var item = _entries.FirstOrDefault(x => x.Id == id);

            if (item == null)
                return false;

            if (!string.IsNullOrWhiteSpace(name))
                item.Name = name.Trim();

            if (date.HasValue)
                item.Date = date.Value;

            item.Comment = comment;

            Save();

            return true;
        }

        private void Load()
        {
            try
            {
                if (!File.Exists(_filePath))
                    return;

                var json = File.ReadAllText(_filePath);

                var data =
                    JsonSerializer.Deserialize<List<BirthdayEntry>>(json);

                if (data == null)
                    return;

                _entries.Clear();
                _entries.AddRange(data);

                _nextId =
                    _entries.Any()
                        ? _entries.Max(x => x.Id) + 1
                        : 1;
            }
            catch
            {
                _entries.Clear();
            }
        }

        private void Save()
        {
            var json = JsonSerializer.Serialize(
                _entries,
                new JsonSerializerOptions
                {
                    WriteIndented = true
                });

            File.WriteAllText(_filePath, json);
        }
    }
}